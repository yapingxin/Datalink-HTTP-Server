#include <stdio.h>
//#include <pthread.h>
//#include "thpool.h"

#include "service_config.h"
#include "logfunc.h"
#include "recvlogic.h"
#include "http_response.h"
#include "thpool.h"


int main(int argc, char **argv)
{
    threadpool thpool;
    int server_sockfd = -1;
    
    thpool = thpool_init(threadpool_threads_count);
    server_sockfd = startup(main_service_port);

	file_output_open(global_log_file_path);

	ZF_LOGI("");
	ZF_LOGI("");
	ZF_LOGI("*****************************************************");
	ZF_LOGI("**       Tiny HTTP Application Server Start        **");
	ZF_LOGI("*****************************************************");
	ZF_LOGI("");

	printf("\n");
	printf("\n");
	printf("*****************************************************\n");
	printf("**       Tiny HTTP Application Server Start        **\n");
	printf("*****************************************************\n");
	printf("\n");

	ZF_LOGI("httpd running on port %i", main_service_port);
	printf("httpd running on port %d\n\n", main_service_port);

	mainloop_recv(server_sockfd, thpool);
    
    thpool_wait(thpool);
    thpool_destroy(thpool);
    
    close(server_sockfd);
    
    return 0;
}

#ifndef _UTILITY_RECVLOGIC_H_
#define _UTILITY_RECVLOGIC_H_

#include "thpool.h"

int startup(unsigned short port);
void mainloop_recv(const int server_sockfd, threadpool thpool);
void error_die(const char *msg);

int disable_tcp_nagle(int sockfd);
int setsockopt_timeout(int sockfd, int timeout_seconds);

#endif // _UTILITY_RECVLOGIC_H_
